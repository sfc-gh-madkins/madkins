#!/usr/bin/env python3
#
# Copyright (c) 2012-2022 Snowflake Computing Inc. All rights reserved.
#
from typing import Union

import pandas as pd
from sklearn.utils.metaestimators import available_if

from snowflake.snowpark import DataFrame


def _final_step_has(attr):
    """Check that final_estimator has `attr`.  Used together with `available_if` in `Pipeline`."""

    def check(self) -> bool:
        # Raises original `AttributeError` if `attr` does not exist.
        # If `attr`` exists but is not callable, then False will be returned.
        return callable(getattr(self.steps[-1][1], attr))

    return check


def has_callable_arrt(obj, attr) -> bool:
    """
    Check if the object `obj` has a callable attribute with the name `attr`.

    Args:
        obj: The object to check
        attr: The name of the attribute to check for.

    Returns:
        True if the attribute is callable, False otherwise
    """
    return callable(getattr(obj, attr, None))


class Pipeline:
    """
    Pipeline of transforms.
    Sequentially apply a list of transforms.
    All steps of the pipeline must be 'transforms', that is, they
    must implement `fit` and `transform`/`predict` methods.
    TODO: SKLearn pipeline expects last step(and only the last step) to be an estimator obj or a dummy estimator(like
            None or passthrough). Currently this Pipeline class works with a list of all transforms or a list of
            transforms ending with an estimator. Should we change this implementation to only work with list of steps
            ending with an estimator or a dummy estimator like SKLearn?

    Args:
        steps: List of (name, transform) tuples (implementing `fit`/`transform`) that
            are chained in sequential order.
    """

    def __init__(self, steps) -> None:
        self.steps = steps
        self._is_final_step_estimator = Pipeline._is_estimator(steps[-1][1])

    @staticmethod
    def _is_estimator(obj) -> bool:
        # TODO(SNOW-723770): Figure out a better way to identify estimator objects.
        return has_callable_arrt(obj, "fit") and has_callable_arrt(obj, "predict")

    @staticmethod
    def _is_transformer(obj) -> bool:
        return has_callable_arrt(obj, "fit") and has_callable_arrt(obj, "transform")

    def _get_transforms(self):
        return self.steps[:-1] if self._is_final_step_estimator else self.steps

    def _get_estimator(self):
        return self.steps[-1] if self._is_final_step_estimator else None

    def _validate_steps(self):
        transforms = self._get_transforms()

        for (_, t) in transforms:
            if not Pipeline._is_transformer(t):
                raise TypeError(
                    "All intermediate steps should be "
                    "transformers and implement both fit() and transform() methods, but"
                    "{name} (type {type}) doesn't".format(name=t, type=type(t))
                )

    def _transform_dataset(self, dataset: Union[DataFrame, pd.DataFrame]) -> Union[DataFrame, pd.DataFrame]:
        transformed_dataset = dataset
        transforms = self._get_transforms()
        for _, (_, trans) in enumerate(transforms):
            transformed_dataset = trans.transform(transformed_dataset)
        return transformed_dataset

    def _fit_transform_dataset(self, dataset: DataFrame) -> DataFrame:
        transformed_dataset = dataset
        transforms = self._get_transforms()
        for _, (_, trans) in enumerate(transforms):
            if has_callable_arrt(trans, "fit_transform"):
                transformed_dataset = trans.fit_transform(transformed_dataset)
            else:
                trans.fit(transformed_dataset)
                transformed_dataset = trans.transform(transformed_dataset)

        return transformed_dataset

    def fit(self, dataset: DataFrame) -> "Pipeline":
        """
        Fit the entire pipeline using the dataset.

        Args:
            dataset: Input dataset.

        Returns:
            Fitted pipeline.
        """

        self._validate_steps()
        dataset_copy = dataset
        dataset_copy = self._fit_transform_dataset(dataset_copy)

        estimator = self._get_estimator()
        if estimator:
            estimator[1].fit(dataset_copy)

        self._is_fitted = True
        return self

    @available_if(_final_step_has("transform"))
    def transform(self, dataset: Union[DataFrame, pd.DataFrame]) -> Union[DataFrame, pd.DataFrame]:
        """
        Call `transform` of each transformer in the pipeline.

        Args:
            dataset: Input dataset.

        Returns:
            Transformed data. Output datatype will be same as input datatype.

        Raises:
            RuntimeError: If the pipeline is not fitted first.
        """

        if not self._is_fitted:
            raise RuntimeError("Pipeline not fitted before calling transform().")

        transformed_dataset = self._transform_dataset(dataset=dataset)
        estimator = self._get_estimator()
        if estimator:
            return estimator[1].transform(transformed_dataset)
        return transformed_dataset

    def _final_step_can_fit_transform(self):
        return has_callable_arrt(self.steps[-1][1], "fit_transform") or (
            has_callable_arrt(self.steps[-1][1], "fit") and has_callable_arrt(self.steps[-1][1], "transform")
        )

    @available_if(_final_step_can_fit_transform)
    def fit_transform(self, dataset: DataFrame) -> DataFrame:
        """
        Fits all the transformer objs one after another and transforms the data. Then fits and tranforms data using the
        estimator. This will only be avaialble if the estimator (or final step) has fit_transform or transform
        methods.

        Args:
            dataset: Input dataset.

        Returns:
            Output dataset.
        """

        self._validate_steps()

        transformed_dataset = dataset
        transformed_dataset = self._fit_transform_dataset(transformed_dataset)

        estimator = self._get_estimator()
        if estimator:
            if has_callable_arrt(estimator[1], "fit_transform"):
                return estimator[1].fit_transform(transformed_dataset)
            else:
                return estimator[1].fit(transformed_dataset).transform(transformed_dataset)

        self._is_fitted = True
        return transformed_dataset

    def _final_step_can_fit_predict(self):
        return has_callable_arrt(self.steps[-1][1], "fit_predict") or (
            has_callable_arrt(self.steps[-1][1], "fit") and has_callable_arrt(self.steps[-1][1], "predict")
        )

    @available_if(_final_step_can_fit_predict)
    def fit_predict(self, dataset: DataFrame) -> DataFrame:
        """
        Fits all the transformer objs one after another and transforms the data. Then fits and predicts using the
        estimator. This will only be avaialble if the estimator (or final step) has fit_predict or predict
        methods.

        Args:
            dataset: Input dataset.

        Returns:
            Output dataset.
        """

        self._validate_steps()

        transformed_dataset = dataset
        transformed_dataset = self._fit_transform_dataset(transformed_dataset)

        estimator = self._get_estimator()
        if estimator:
            if has_callable_arrt(estimator[1], "fit_predict"):
                transformed_dataset = estimator[1].fit_predict(transformed_dataset)
            else:
                transformed_dataset = estimator[1].fit(transformed_dataset).predict(transformed_dataset)

        self._is_fitted = True
        return transformed_dataset

    # TODO(snandamuri): Support pandas dataframe in predict method in estimators. Then change Pipeline.predict()
    # method to support pandas dataframe.
    @available_if(_final_step_has("predict"))
    def predict(self, dataset: DataFrame) -> DataFrame:
        """
        Transform the dataset by applying all the transformers in order and predict using the estimator.

        Args:
            dataset: Input dataset.

        Returns:
            Output dataset.

        Raises:
            RuntimeError: If the pipeline is not fitted first.
        """

        if not self._is_fitted:
            raise RuntimeError("Pipeline not fitted before calling predict().")

        transformed_dataset = self._transform_dataset(dataset=dataset)
        estimator = self._get_estimator()
        # Estimator is guaranteed to be not None because of _final_step_has("predict") check.
        return estimator[1].predict(transformed_dataset)

    @available_if(_final_step_has("predict_proba"))
    def predict_proba(self, dataset: DataFrame) -> DataFrame:
        """
        Transform the dataset by applying all the transformers in order and apply `predict_proba` using the estimator.

        Args:
            dataset: Input dataset.

        Returns:
            Output dataset.

        Raises:
            RuntimeError: If the pipeline is not fitted first.
        """

        if not self._is_fitted:
            raise RuntimeError("Pipeline not fitted before calling predict_proba().")

        transformed_dataset = self._transform_dataset(dataset=dataset)
        estimator = self._get_estimator()
        # Estimator is guaranteed to be not None because of _final_step_has("predict_proba") check.
        return estimator[1].predict_proba(transformed_dataset)

    @available_if(_final_step_has("predict_log_proba"))
    def predict_log_proba(self, dataset: DataFrame) -> DataFrame:
        """
        Transform the dataset by applying all the transformers in order and apply `predict_log_proba` using the
        estimator.

        Args:
            dataset: Input dataset.

        Returns:
            Output dataset.

        Raises:
            RuntimeError: If the pipeline is not fitted first.
        """

        if not self._is_fitted:
            raise RuntimeError("Pipeline not fitted before calling predict_log_proba().")

        transformed_dataset = self._transform_dataset(dataset=dataset)
        estimator = self._get_estimator()
        # Estimator is guaranteed to be not None because of _final_step_has("predict_log_proba") check.
        return estimator[1].predict_log_proba(transformed_dataset)

    @available_if(_final_step_has("score"))
    def score(self, dataset: DataFrame) -> DataFrame:
        """
        Transform the dataset by applying all the transformers in order and apply `score` using the estimator.

        Args:
            dataset: Input dataset.

        Returns:
            Output dataset.

        Raises:
            RuntimeError: If the pipeline is not fitted first.
        """

        if not self._is_fitted:
            raise RuntimeError("Pipeline not fitted before calling score().")

        transformed_dataset = self._transform_dataset(dataset=dataset)
        estimator = self._get_estimator()
        # Estimator is guaranteed to be not None because of _final_step_has("score") check.
        return estimator[1].score(transformed_dataset)
