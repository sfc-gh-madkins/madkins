import os
import sys
import typing as t
from abc import ABC, abstractstaticmethod
from pathlib import Path

import cloudpickle

from snowflake.ml.model.model_meta import ModelMetadata
from snowflake.ml.model.type_spec import TypeSpec, infer_spec
from snowflake.ml.model.types import LazyType
from snowflake.ml.model.util import copy_file_or_tree

ModelType = t.Any

MODEL_HANDLER_REGISTRY = dict()


def register_handler(cls):
    MODEL_HANDLER_REGISTRY[cls.type] = cls
    return cls


class BaseModelContainer:
    """Common base class enforcing an interface to be used for autogen inference."""

    def predict(self, X):
        pass


class ModelHandler(ABC):
    """Provides handling for a given type of model defined by `type` class property."""

    type = None

    @abstractstaticmethod
    def can_handle(model: ModelType) -> bool:
        """Whether this handler could support the tyep of the `model`.

        Args:
            model (ModelType): The model object.

        Returns:
            bool: True if could handle `model`.
        """
        ...

    @abstractstaticmethod
    def infer_schema(model: ModelType, X: t.Any) -> t.Tuple[TypeSpec, TypeSpec]:
        """Infer both input and output schema type based on `model` and sampled input data.

        Args:
            model (ModelType): The model object.
            X (t.Any): Sample input data.

        Returns:
            t.Tuple[TypeSpec, TypeSpec]: A tuple of input and output spec.
        """
        ...

    @abstractstaticmethod
    def _save_model(model: ModelType, model_meta: ModelMetadata, model_dir_path: str, **kwargs):
        """Save the model.

        Args:
            model (ModelType): The model object.
            model_meta (ModelMeta): The model metadata.
            model_dir_path (str): Directory path to the model.
        """
        ...

    @abstractstaticmethod
    def _load_model(model_meta: ModelMetadata, model_dir_path: str):
        """Load the model into memory.

        Args:
            model_meta (ModelMeta): The model metadata.
            model_dir_path (str): Directory path to the model.
        """
        ...

    @abstractstaticmethod
    def _load_model_container(model_meta: ModelMetadata, model_dir_path: str):
        """Load the model into memory within a container.

        Args:
            model_meta (ModelMeta): The model metadata.
            model_dir_path (str): Directory path to the model.
        """
        ...


def find_handler(model: ModelType) -> t.Optional[ModelHandler]:
    for handler in MODEL_HANDLER_REGISTRY.values():
        if handler.can_handle(model):
            return handler
    return None


def load_handler(target_model_type: str) -> t.Optional[ModelHandler]:
    for model_type, handler in MODEL_HANDLER_REGISTRY.items():
        if target_model_type == model_type:
            return handler
    return None


@register_handler
class SKLModelHandler(ModelHandler):
    type = "sklearn"

    @staticmethod
    def can_handle(model) -> bool:
        return (
            LazyType("sklearn.base.BaseEstimator").isinstance(model)
            or LazyType("sklearn.pipeline.Pipeline").isinstance(model)
        ) and hasattr(model, "predict")

    @staticmethod
    def infer_schema(model, X):
        input_spec = infer_spec(X)
        y = model.predict(X)
        output_spec = infer_spec(y)
        return (input_spec, output_spec)

    @staticmethod
    def _save_model(model: ModelType, model_meta: ModelMetadata, model_dir_path: str, **kwargs):
        with open(os.path.join(model_dir_path, "model.pkl"), "wb") as f:
            cloudpickle.dump(model, f)
        assert (
            "sample_data" in kwargs and kwargs["sample_data"] is not None
        ), "Sample data is needed for schema inference."
        input_spec, output_spec = SKLModelHandler.infer_schema(model, kwargs["sample_data"])
        model_meta.input_spec = input_spec
        model_meta.output_spec = output_spec
        model_meta.model_type = {SKLModelHandler.type: dict()}

    @staticmethod
    def _load_model(model_meta: ModelMetadata, model_dir_path: str):
        with open(os.path.join(model_dir_path, "model.pkl"), "rb") as f:
            m = cloudpickle.load(f)
        return m

    @staticmethod
    def _load_model_container(model_meta: ModelMetadata, model_dir_path: str):
        m = SKLModelHandler._load_model(model_meta, model_dir_path)

        class _SKLWrapper(BaseModelContainer):
            def predict(self, X):
                return m.predict(X)

        return _SKLWrapper()


@register_handler
class CustomModelHandler(ModelHandler):
    type = "custom"

    @staticmethod
    def can_handle(model) -> bool:
        return LazyType("snowflake.ml.model.custom_model.CustomModel").isinstance(model)

    @staticmethod
    def _save_model(model: ModelType, model_meta: ModelMetadata, model_dir_path: str, **kwargs):
        model._validate()
        model_meta.input_spec = model._input_spec
        model_meta.output_spec = model._output_spec
        model_meta.artifacts = model.context.artifacts.copy()
        if model.context.artifacts:
            artifacts_path = os.path.join(model_dir_path, "artifacts")
            os.makedirs(artifacts_path, exist_ok=True)
            for _name, uri in model.context.artifacts.items():
                copy_file_or_tree(uri, artifacts_path)

        if "code_paths" in kwargs and kwargs["code_paths"] is not None:
            code_paths = kwargs["code_paths"]
            code_dir_path = os.path.join(model_dir_path, "code")
            os.makedirs(code_dir_path, exist_ok=True)
            for code_path in code_paths:
                copy_file_or_tree(code_path, code_dir_path)

        with open(os.path.join(model_dir_path, "model.pkl"), "wb") as f:
            imported_modules = []
            try:
                if "ext_modules" in kwargs and kwargs["ext_modules"] is not None:
                    ext_modules = kwargs["ext_modules"]
                    registered_modules = cloudpickle.list_registry_pickle_by_value()
                    for mod in ext_modules:
                        if mod.__name__ not in registered_modules:
                            cloudpickle.register_pickle_by_value(mod)
                            imported_modules.append(mod)
                cloudpickle.dump(model, f)
            finally:
                for mod in imported_modules:
                    cloudpickle.unregister_pickle_by_value(mod)

        model_meta.model_type = {CustomModelHandler.type: dict()}

    @staticmethod
    def _load_model(model_meta: ModelMetadata, model_dir_path: str):
        from snowflake.ml.model.custom_model import ModelContext

        with open(os.path.join(model_dir_path, "model.pkl"), "rb") as f:
            m = cloudpickle.load(f)
        artifacts_meta = model_meta.artifacts
        artifacts = {
            name: os.path.join(model_dir_path, "artifacts", rel_path) for name, rel_path in artifacts_meta.items()
        }
        code_path = os.path.join(model_dir_path, "code")
        if os.path.exists(code_path):
            sys.path = [code_path] + sys.path
            modules = [
                p.stem
                for p in Path(code_path).rglob("*.py")
                if p.is_file() and p.name != "__init__.py" and p.name != "__main__.py"
            ]
            for module in modules:
                sys.modules.pop(module, None)
        ctx = ModelContext(artifacts)
        m.context = ctx
        return m

    @staticmethod
    def _load_model_container(model_meta: ModelMetadata, model_dir_path: str):
        m = CustomModelHandler._load_model(model_meta, model_dir_path)

        class _CustomModelWrapper(BaseModelContainer):
            def predict(self, X):
                return m._user_func(X)

        return _CustomModelWrapper()
