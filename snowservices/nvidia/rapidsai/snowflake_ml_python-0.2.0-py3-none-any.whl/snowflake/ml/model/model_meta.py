import os
import typing as t
from datetime import datetime

import yaml

from snowflake.ml.model.type_spec import TypeSpec


class ModelMetadata:
    """Model metadata for Snowflake native model packaged model."""

    def __init__(
        self,
        *,
        name: str,
        python_version: str,
        artifacts: t.Optional[t.Dict[str, str]] = None,
        input_spec: t.Optional[TypeSpec] = None,
        output_spec: t.Optional[TypeSpec] = None,
        model_type: t.Dict[str, t.Dict] = None,
        metadata: t.Optional[t.Dict[str, t.Any]] = None,
        **kwargs
    ) -> None:
        self.name = name
        self._input_spec = input_spec
        self._output_spec = output_spec
        self.metadata = metadata
        self.utc_time_created = str(datetime.utcnow())
        self.model_type = model_type
        self.artifacts = artifacts
        self.python_version = python_version
        self.__dict__.update(kwargs)

    @property
    def input_spec(self):
        return self._input_spec

    @input_spec.setter
    def input_spec(self, v):
        self._input_spec = v

    @property
    def output_spec(self):
        return self._output_spec

    @output_spec.setter
    def output_spec(self, v):
        self._output_spec = v

    def to_dict(self):
        self._validate()
        res = {k: v for k, v in self.__dict__.items() if not k.startswith("_")}
        res["schema"] = {"input_spec": self._input_spec.to_dict(), "output_spec": self._output_spec.to_dict()}
        return res

    @classmethod
    def from_dict(cls, model_dict):
        model_dict["input_spec"] = TypeSpec.from_dict(model_dict["schema"]["input_spec"])
        model_dict["output_spec"] = TypeSpec.from_dict(model_dict["schema"]["output_spec"])
        return cls(**model_dict)

    def save_yaml(self, path):
        with open(path, "w") as out:
            yaml.safe_dump(self.to_dict(), stream=out, default_flow_style=False)

    def _validate(self):
        assert self._input_spec is not None, "Input spec has to be set."
        assert self._output_spec is not None, "Output spec has to be set."
        assert self.model_type is not None, "Model type has to be set."

    @classmethod
    def load(cls, path):
        path = os.path.join(path, "model.yaml")
        with open(path) as f:
            return cls.from_dict(yaml.safe_load(f.read()))
