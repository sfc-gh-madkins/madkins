import sys
import typing as t

import typing_extensions as te

T = t.TypeVar("T")


class LazyType(t.Generic[T]):
    """Utility type to help defer need of importing."""

    def __init__(self, klass: t.Union[str, t.Type[T]]) -> None:
        if isinstance(klass, str):
            parts = klass.rsplit(".", 1)
            assert len(parts) == 2, "Not a class"
            self.module, self.qualname = parts
            self._runtime_class = None
        else:
            self._runtime_class = klass
            self.module = klass.__module__
            if hasattr(klass, "__qualname__"):
                self.qualname: str = klass.__qualname__
            else:
                self.qualname: str = klass.__name__

    def __instancecheck__(self, obj: object) -> te.TypeGuard[T]:
        return self.isinstance(obj)

    @classmethod
    def from_type(cls, typ_: t.Union["LazyType[T]", t.Type[T]]) -> "LazyType[T]":
        if isinstance(typ_, LazyType):
            return typ_
        return cls(typ_)

    def __eq__(self, o: object) -> bool:
        if isinstance(o, type):
            o = self.__class__(o)
        if isinstance(o, LazyType):
            return self.module == o.module and self.qualname == o.qualname
        return False

    def __hash__(self) -> int:
        return hash(f"{self.module}.{self.qualname}")

    def __repr__(self) -> str:
        return f'LazyType("{self.module}", "{self.qualname}")'

    def get_class(self) -> t.Type[T]:
        if self._runtime_class is None:
            try:
                m = sys.modules[self.module]
            except KeyError:
                raise ValueError(f"Module {self.module} not imported")

            self._runtime_class = t.cast("t.Type[T]", getattr(m, self.qualname))

        return self._runtime_class

    def isinstance(self, obj: t.Any) -> te.TypeGuard[T]:
        try:
            return isinstance(obj, self.get_class())
        except ValueError:
            return False
