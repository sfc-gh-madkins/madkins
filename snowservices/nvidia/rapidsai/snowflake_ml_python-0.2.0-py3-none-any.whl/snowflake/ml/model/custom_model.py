import functools
import inspect
from abc import ABC


class ModelContext:
    def __init__(self, artifacts=None) -> None:
        self.artifacts = artifacts if artifacts else dict()

    def path(self, key):
        return self.artifacts[key]


class CustomModel(ABC):
    _input_spec = None
    _output_spec = None
    _user_func = None

    def __init__(self, context: ModelContext) -> None:
        self.context = context

    @classmethod
    def api(cls, input_spec, output_spec):
        def inner(user_func):
            cls._user_func = user_func
            cls._input_spec = input_spec
            cls._output_spec = output_spec

            @functools.wraps(user_func)
            def wrapper(self, arg):
                return user_func(self, arg)

            return wrapper

        return inner

    def _validate(self):
        if not self._input_spec or not self._output_spec:
            raise RuntimeError("Input or output spec not specified.")
        sig = inspect.signature(self._user_func)
        assert len(sig.parameters) == 1, "API should only has single argument."
        assert (
            sig.parameters[next(iter(sig.parameters))].annotation == self._input_spec.py_type()
        ), f"Input type mis-matching. spec: f{self._input_spec.py_type()},"
        " annotation: f{sig.parameters[next(iter(sig.parameters))].annotation}"
        assert sig.return_annotation == self._output_spec.py_type(), "output type mis-match."
