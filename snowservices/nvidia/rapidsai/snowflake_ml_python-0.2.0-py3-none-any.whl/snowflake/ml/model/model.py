import os
from typing import Any, Dict, List

from snowflake.ml.model import model_handler, model_meta
from snowflake.ml.model.env import PYTHON_VERSION, generate_env_files


def save_model(
    *,
    name: str,
    model_dir_path: str,
    model: Any,
    metadata: Dict[str, Any],
    pip_requirements: List[str] = None,
    ext_modules=None,
    code_paths=None,
    sample_data=None,
):
    """Save the model under `dir_path`.

    Args:
        name (_type_): _description_
        dir_path (_type_): _description_
        model (CustomModel): _description_
        metadata (Dict[str, Any]): _description_
        pip_requirements: List of PIP package specs.
        code_paths: Directory of code to import.
        ext_modules (_type_, optional): _description_. Defaults to None.

    """
    handler = model_handler.find_handler(model)
    if handler is None:
        raise TypeError(f"{type(model)} is not supported.")
    if not os.path.exists(model_dir_path):
        os.makedirs(model_dir_path)
    meta = model_meta.ModelMetadata(name=name, metadata=metadata, python_version=PYTHON_VERSION)
    handler._save_model(
        model, meta, model_dir_path, ext_modules=ext_modules, code_paths=code_paths, sample_data=sample_data
    )
    meta.save_yaml(os.path.join(model_dir_path, "model.yaml"))
    if pip_requirements:
        generate_env_files(model_dir_path, pip_requirements)


# TODO: Allows path to be stage path.
def load_model(model_dir_path):
    """Load the model into memory from directory.

    Args:
        model_dir_path (_type_): Directory containing the model.

    Raises:
        TypeError: Raise if model is not native format.

    Returns:
        _type_: _description_
    """
    meta = model_meta.ModelMetadata.load(model_dir_path)
    handler = model_handler.load_handler(next(iter(meta.model_type.keys())))
    if handler is None:
        raise TypeError(f"{meta.model_type} is not supported.")
    m = handler._load_model(meta, model_dir_path)
    return m, meta
