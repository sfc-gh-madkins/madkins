#
# Copyright (c) 2012-2022 Snowflake Computing Inc. All rights reserved.
#
import math
from typing import Collection, Iterable, List, Optional, Tuple
from uuid import uuid4

import cloudpickle
import numpy as np
import pandas as pd

from snowflake import snowpark
from snowflake.snowpark import types as snowpark_types


def correlation(*, df: snowpark.DataFrame, columns: Optional[Collection[str]] = None) -> pd.DataFrame:
    """Pairwise Pearson correlation between the columns in a snowpark dataframe.
    NaNs and Nulls are not ignored, i.e. correlation on columns containing NaN or Null
    results in NaN correlation values.
    Returns a pandas dataframe containing the correlation matrix.

    The below steps explain how correlation matrix is computed in a distributed way:
    Let n = # of rows in the dataframe; sqrt_n = sqrt(n); X, Y are 2 columns in the dataframe
    Correlation(X, Y) = numerator/denominator where
    numerator = dot(X/sqrt_n, Y/sqrt_n) - sum(X/n)*sum(X/n)
    denominator = std_dev(X)*std_dev(Y)
    std_dev(X) = sqrt(dot(X/sqrt_n, X/sqrt_n) - sum(X/n)*sum(X/n))

    Note that the formula is entirely written using dot and sum operators on columns. Using first UDTF, we compute the
    dot and sum of columns for different shards in parallel. In the second UDTF, dot and sum is accumulated
    from all the shards. The final computation for numerator, denominator and division is done on the client side
    as a post-processing step.

    Args:
        df (snowpark.DataFrame): Snowpark Dataframe for which correlation has to be computed.
        columns (Optional[Collection[str]]): List of column names for which the correlation has to be computed.
            If None, correlation is computed for all numeric columns in the snowpark dataframe.

    Returns:
        Correlation matrix in pandas.DataFrame format.

    Raises:
        ValueError: If non-numeric columns are provided in the input arg, columns.
    """
    statement_params = {"SNOWML": "CORRELATION"}

    # Validate input arguments
    input_df = df
    if columns is None:
        columns = [c.name for c in input_df.schema.fields if issubclass(type(c.datatype), snowpark_types._NumericType)]
        input_df = input_df.select(columns)
    else:
        input_df = input_df.select(columns)
        for c in input_df.schema.fields:
            if not issubclass(type(c.datatype), snowpark_types._NumericType):
                msg = "Column: {} is not a numeric column"
                raise ValueError(msg.format(c.name))

    class ShardedDotAndSumComputer:
        """This class is registered as a UDTF and computes the sum and dot product
        of columns for each partition of rows. The computations across all the partitions happens
        in parallel using the nodes in the warehouse. In order to avoid keeping the entire partition
        in memory, we batch the rows (size is 1000) and maintain a running sum and dot prod in self._sum
        and self._dot_prod respectively. We return these at the end of the partition.
        """

        def __init__(self) -> None:
            self._variables_initialized = False
            # 2d array containing pairwise dot product of all columns - sum(col1*col2/num_rows).
            self._dot_prod = np.zeros((1, 1))
            # Setting the batch size to 1000 based on experimentation. Can be fine tuned later.
            self._batch_size = 1000
            # 2d array containing a batch of input rows. A batch contains self._batch_size rows.
            self._batched_rows = np.zeros((self._batch_size, 1))
            # 1d array of length = # of cols. Contains sum(col/sqrt_num_rows) for each column.
            self._sum = np.zeros(1)
            # Number of columns in the dataset.
            self._n_cols = -1
            # Running count of number of rows added to self._batched_rows.
            self._cur_count = 0
            # Square root of the number of rows in the dataset.
            self._sqrt_n = -1.0

        def process(self, input_row: List[float], sqrt_n: str) -> None:
            # 1. initialization of variables
            if not self._variables_initialized:
                self._n_cols = len(input_row)
                self._sqrt_n = float(sqrt_n)
                self._sum = np.zeros(self._n_cols)
                self._batched_rows = np.zeros((self._batch_size, self._n_cols))
                self._dot_prod = np.zeros((self._n_cols, self._n_cols))
            self._variables_initialized = True

            self._batched_rows[self._cur_count, :] = input_row
            self._cur_count += 1

            # 2. Compute incremental sum and dot_prod for the batch.
            if self._cur_count >= self._batch_size:
                self.accumulate_batch_sum_and_dot_prod()
                self._cur_count = 0

        def end_partition(self) -> Iterable[Tuple[bytes, str]]:
            # 3. Compute sum and dot_prod for the remaining rows in the batch.
            if self._cur_count > 0:
                self.accumulate_batch_sum_and_dot_prod()
            for i in range(self._n_cols):
                yield (cloudpickle.dumps(self._dot_prod[i, :]), "row_" + str(i))
            yield (cloudpickle.dumps(self._sum), "sum")

        def accumulate_batch_sum_and_dot_prod(self) -> None:
            self._batched_rows = self._batched_rows / self._sqrt_n
            self._sum += np.sum(self._batched_rows[0 : self._cur_count, :], axis=0)
            self._dot_prod += np.einsum(
                "nt, nm -> tm",
                self._batched_rows[0 : self._cur_count, :],
                self._batched_rows[0 : self._cur_count, :],
                optimize="optimal",
            )

    sharded_dot_and_sum_computer = "ShardedDotAndSumComputer_{}".format(str(uuid4()).replace("-", "_").upper())
    input_df._session.udtf.register(
        ShardedDotAndSumComputer,
        output_schema=snowpark_types.StructType(
            [
                snowpark_types.StructField("result", snowpark_types.BinaryType()),
                snowpark_types.StructField("part", snowpark_types.StringType()),
            ]
        ),
        input_types=[snowpark_types.ArrayType(), snowpark_types.StringType()],
        packages=["numpy", "cloudpickle"],
        name=sharded_dot_and_sum_computer,
        is_permanent=False,
        replace=True,
        statement_params=statement_params,
    )

    class DotAndSumAccumulator:
        """This class is registered as a UDTF. sum and dot product from previous UDTF are accumulated in this UDTF.
        Final sum and dot_prod for all rows in the original dataframe is returned from this UDTF.
        """

        def __init__(self) -> None:
            self._corr_arr = None

        def process(self, input_row: bytes) -> None:
            row = cloudpickle.loads(input_row)
            if self._corr_arr is None:
                self._corr_arr = row
            else:
                self._corr_arr = self._corr_arr + row

        def end_partition(self) -> Iterable[Tuple[bytes]]:
            yield (cloudpickle.dumps(self._corr_arr),)

    dot_and_sum_accumulator = "DotAndSumAccumulator_{}".format(str(uuid4()).replace("-", "_").upper())
    input_df._session.udtf.register(
        DotAndSumAccumulator,
        output_schema=snowpark_types.StructType(
            [
                snowpark_types.StructField("result", snowpark_types.BinaryType()),
            ]
        ),
        input_types=[snowpark_types.BinaryType()],
        packages=["numpy", "cloudpickle"],
        name=dot_and_sum_accumulator,
        is_permanent=False,
        replace=True,
        statement_params=statement_params,
    )
    count = input_df.count(statement_params=statement_params)
    sqrt_count = math.sqrt(count)

    # TODO: Move the below to snowpark dataframe operations
    input_query = input_df.queries["queries"][-1]
    query = f"""
        with temp_table1 as
        (select array_construct(*) as col from ({input_query})),
        temp_table2 as
        (select result as res, part from temp_table1,
        table({sharded_dot_and_sum_computer}(temp_table1.col, '{str(sqrt_count)}')))
        select result, temp_table2.part from temp_table2,
        table({dot_and_sum_accumulator}(temp_table2.res) over (partition by part))
    """
    results = input_df._session.sql(query).collect(statement_params=statement_params)

    # The below computation can be moved to a third udtf. But there is not much benefit in terms of client side
    # resource consumption as the below computation is very fast (< 1 sec for 1000 cols). Memory is in the same order
    # as the resultant correlation matrix.
    # Pushing this to a udtf requires creating a temp udtf which takes about 20 secs, so it doesn't make sense
    # to have this in a udtf.
    n_cols = len(columns)
    sum_arr = np.zeros(n_cols)
    squared_sum_arr = np.zeros(n_cols)
    dot_prod = np.zeros((n_cols, n_cols))
    # Get sum, dot_prod and squared sum array from the results.
    for i in range(len(results)):
        x = results[i]
        if x[1] == "sum":
            sum_arr = cloudpickle.loads(x[0])
        else:
            row = int(x[1].strip("row_"))
            dot_prod[row, :] = cloudpickle.loads(x[0])
            squared_sum_arr[row] = dot_prod[row, row]

    sum_arr = sum_arr / sqrt_count

    # sum(X/n)*sum(Y/n) is computed for all combinations of X,Y (columns in the dataframe)
    exey_arr = np.einsum("t,m->tm", sum_arr, sum_arr, optimize="optimal")
    numerator_matrix = dot_prod - exey_arr

    # standard deviation for all columns in the dataframe
    stddev_arr = np.sqrt(squared_sum_arr - np.einsum("i, i -> i", sum_arr, sum_arr, optimize="optimal"))
    # std_dev(X)*std_dev(Y) is computed for all combinations of X,Y (columns in the dataframe)
    denominator_matrix = np.einsum("t,m->tm", stddev_arr, stddev_arr, optimize="optimal")
    corr_res = numerator_matrix / denominator_matrix
    correlation_matrix = pd.DataFrame(corr_res, columns=columns, index=columns)
    return correlation_matrix
