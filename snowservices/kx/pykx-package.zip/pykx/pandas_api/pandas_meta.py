def _init(_q):
    global q
    q = _q


class PandasMeta:
    # Dataframe properties
    @property
    def columns(self):
        return q('{if[99h~type x; x:value x]; cols x}', self).py()

    @property
    def dtypes(self):
        return q('{0#x}', self).pd().dtypes

    @property
    def empty(self):
        return q('{0~count x}', self).py()

    @property
    def ndim(self):
        return q('{if[99h~type x; x:value x]; count cols x}', self).py()

    @property
    def shape(self):
        return tuple(q('{if[99h~type x; x:value x]; (count x; count cols x)}', self).py())

    @property
    def size(self):
        return q('{count[x] * count[cols x]}', self).py()
