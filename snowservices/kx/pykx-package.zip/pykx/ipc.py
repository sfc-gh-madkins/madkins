"""PyKX q IPC interface.

The IPC communication module provided here works differently than may be expected for users
familiar with the KX IPC interfaces provided for Java and C#. Unlike these interfaces it does not
directly convert the encoded data received over the q IPC protocol to an analogous type in Python,
but rather stores the object within q memory space as a `pykx.K` object for deferred conversion.

This has major benefits with regards to the flexibility of the interface. In particular, the
[`pykx.K`][pykx.K] conversion methods (i.e. `py`, `np`, `pd`, and `pa`), use the same logic as they
do when converting `pykx.K` objects that were created by an embedded q instance.

The IPC interface works when running with or without a q license. Refer to
[the modes of operation documentation](../user-guide/advanced/modes.md) for more details.

The IPC Interface is split between two classes `pykx.AsyncQConnection` and `pykx.SyncQConnection`.
Both of which extend the base `QConnection` class, instantiating a `QConnection` directly remains
possible for backward compatibility but will now return an instance of `pykx.SyncQConnection`. There
is also the `pykx.RawQConnection` class that is a superset of the `pykx.AsyncQConnection` class that
has extra functionality around manually polling the send an receive message queues.

For more examples of usage of the IPC interface you can look at the
[`interface overview`](../getting-started/interface_overview.html#ipc-communication).
"""

from abc import abstractmethod
import asyncio
from contextlib import nullcontext
from multiprocessing import Lock as multiprocessing_lock
import selectors
import socket
from threading import Lock as threading_lock
from time import monotonic_ns
from typing import Any, Callable, Optional, Union
from warnings import warn
from weakref import finalize

from . import Q
from .config import max_error_length, pykx_lib_dir, system
from .core import licensed
from .exceptions import FutureCancelled, NoResults, PyKXException, QError, UninitializedConnection
from .util import get_default_args, normalize_to_bytes, normalize_to_str
from .wrappers import CharVector, Composition, Foreign, Function, K, List
from . import _wrappers
from . import _ipc


__all__ = [
    'AsyncQConnection',
    'QConnection',
    'QFuture',
    'RawQConnection',
    'SecureQConnection',
    'SyncQConnection',
]


def __dir__():
    return __all__


def _init(_q):
    global q
    q = _q


class QFuture(asyncio.Future):
    """
    A Future object to be returned by calls to q from an instance of `pykx.AsyncQConnection`.

    This object can be awaited to receive the resulting value.

    Examples:

    Awaiting an instance of this class to receive the return value of an `AsyncQConnection` call.

    ```python
    async with pykx.AsyncQConnection('localhost', 5001) as q:
        q_future = q('til 10') # returns a QFuture object
        q_result = await q_future
    ```
    """
    _result = None
    _exception = None
    _callbacks = []

    def __init__(self, q_connection, timeout):
        self.q_connection = q_connection
        self._done = False
        self._cancelled = False
        self._cancelled_message = ''
        self._timeout = timeout
        super().__init__()

    def __await__(self) -> Any:
        """Await the result of the `QFuture`.

        Returns:
            The result of the `QFuture`.

        Raises:
            FutureCancelled: This QFuture instance has been cancelled and cannot be awaited.
            BaseException: If the future has an exception set it will be raised upon awaiting it.
        """
        if self.done():
            return self.result()
        while not self.done():
            self.q_connection._recv()
        yield from self
        super().__await__()
        return self.result()

    async def __async_await__(self) -> Any:
        return await self

    def _await(self) -> Any:
        if self.done():
            return self.result()
        while not self.done():
            self.q_connection._recv(locked=True)
        return self.result()

    def set_result(self, val: Any) -> None:
        """Set the result of the `QFuture` and mark it as done.

        If there are functions in the callback list they will be called using this `QFuture`
        instance as the only parameter after the result is set.

        Parameters:
            val: The value to set as the result of the `QFuture`.
        """
        self._result = val
        for _ in self._callbacks:
            callback = self._callbacks.pop(0)
            callback(self)
        self._done = True

    def set_exception(self, err: Exception) -> None:
        """Set the exception of the `QFuture` and mark it as done.

        Parameters:
            err: The exception to set as the exception of the `QFuture`.
        """
        self._done = True
        self._exception = err

    def result(self) -> Any:
        """Get the result of the `QFuture`.

        Returns:
            The result of the `QFuture`.

        Raises:
            FutureCancelled: This QFuture instance has been cancelled and cannot be awaited.
            NoResults: The result is not ready.
        """
        if self._exception is not None:
            raise self._exception
        if self._cancelled:
            raise FutureCancelled(self._cancelled_message)
        if self._result is not None:
            return self._result
        raise NoResults()

    def done(self) -> bool:
        """
        Returns:
            `True` if the `QFuture` is done or if it has been cancelled.
        """
        return self._done or self._cancelled

    def cancelled(self) -> bool:
        """
        Returns:
            `True` if the `QFuture` has been cancelled.
        """
        return self._cancelled

    def cancel(self, msg: str = '') -> None:
        """Cancel the `QFuture`.

        Parameters:
            msg: An optional message to append to the end of the `pykx.FutureCancelled` exception.
        """
        self._cancelled = True
        self._cancelled_message = msg

    def exception(self) -> None:
        """Get the exception of the `QFuture`.

        Returns:
            The excpetion of the `QFuture` object.
        """
        if self._cancelled:
            return FutureCancelled(self._cancelled_message)
        if not self._done:
            return NoResults()
        return self._exception

    def add_done_callback(self, callback: Callable):
        """Add a callback function to be ran when the `QFuture` is done.

        Note: The callback should expect one parameter that is the current instance of this class.
            The functions are called when the result of the future is set and therefore can use the
            result and modify it.

        Parameters:
            callback: The callback function to be called when the result is set.
        """
        self._callbacks.append(callback)

    def remove_done_callback(self, callback: Callable) -> int:
        """Remove a callback from the list of callbacks contained within the class.

        All matching callbacks will be removed.

        Parameters:
            callback: The callback function to be removed from the list of callback functions to
                call.

        Returns:
            The number of functions removed.
        """
        new_callbacks = [c for c in self._callbacks if c != callback]
        removed = len(self._callbacks) - len(new_callbacks)
        self._callbacks = new_callbacks
        return removed

    def get_loop(self):
        """
        Raises:
            PyKXException: QFutures do not rely on an event loop to drive them, and therefore do not
                have one.
        """
        raise PyKXException('QFutures do not rely on an event loop to drive them, '
                            'and therefore do not have one.')

    __iter__ = __await__


class QConnection(Q):
    _ipc_errors = {
        0: 'Authentication error',
        -1: 'Connection error',
        -2: 'Timeout error',
        -3: 'OpenSSL initialization failed',
    }

    _sync_deprecation_warning = ("The 'sync' parameter is deprecated - use the 'wait'"
                                 " parameter instead.")

    # 65536 is the read size the the c/e libs use internally for IPC requests
    _socket_buffer_size = 65536

    def __new__(cls, *args, **kwargs):
        if cls is QConnection:
            if 'tls' in kwargs.keys() and kwargs['tls']:
                return SecureQConnection(*args, **kwargs)
            return SyncQConnection(*args, **kwargs)
        return object.__new__(cls)

    def __init__(self,
                 host: Union[str, bytes] = 'localhost',
                 port: int = None,
                 *args,
                 username: Union[str, bytes] = '',
                 password: Union[str, bytes] = '',
                 timeout: float = 0.0,
                 large_messages: bool = True,
                 tls: bool = False,
                 unix: bool = False,
                 sync: bool = None,
                 wait: bool = True,
                 lock: Optional[Union[threading_lock, multiprocessing_lock]] = None,
                 no_ctx: bool = False
    ):
        """Interface with a q process using the q IPC protocol.

        Note: Creating an instance of this class returns an instance of `pykx.SyncQConnection`.
            Directly instantiating an instance of `pykx.SyncQConnection` is recommended, but
            this behaviour will remain for backwards compatibility.

        Parameters:
            host: The host name to which a connection is to be established.
            port: The port to which a connection is to be established.
            username: Username for q connection authorization.
            password: Password for q connection authorization.
            timeout: Timeout for blocking socket operations in seconds. If set to `0`, the socket
                will be non-blocking.
            large_messages: Whether support for messages >2GB should be enabled.
            tls: Whether TLS should be used.
            unix: Whether a Unix domain socket should be used instead of TCP. If set to `True`, the
                host parameter is ignored. Does not work on Windows.
            sync: This parameter is deprecated - use `wait` instead.
            wait: Whether the q server should send a response to the query (which this connection
                will wait to receive). Can be overridden on a per-call basis. If `True`, Python will
                wait for the q server to execute the query, and respond with the results. If
                `False`, the q server will respond immediately to every query with generic null
                (`::`), then execute them at some point in the future.
            no_ctx: This parameter determines whether or not the context interface will be disabled.
                disabling the context interface will stop extra q queries being sent but will
                disable the extra features around the context interface.

        Note: The `username` and `password` parameters are not required.
            The `username` and `password` parameters are only required if the q server requires
            authorization. Refer to [ssl documentation](https://code.kx.com/q/kb/ssl/) for more
            information.

        Note: The `timeout` argument may not always be enforced when making succesive querys.
            When making successive queries if one query times out the next query will wait until a
            response has been recieved from the previous query before starting the timer for its own
            timeout. This can be avioded by using a seperate `QConnection` instance for each query.

        Note: When querying `KX Insights` the `no_ctx=True` keyword argument must be used.

        Raises:
            PyKXException: Using both tls and unix is not possible with a QConnection.
        """
        super().__init__()

    def _init(self,
              host: Union[str, bytes] = 'localhost',
              port: int = None,
              *,
              username: Union[str, bytes] = '',
              password: Union[str, bytes] = '',
              timeout: float = 0.0,
              large_messages: bool = True,
              tls: bool = False,
              unix: bool = False,
              wait: bool = True,
              lock: Optional[Union[threading_lock, multiprocessing_lock]] = None,
              no_ctx: bool = False
    ):
        object.__setattr__(self, '_connection_info', {
            'host': host,
            'port': port,
            'username': username,
            'password': password,
            'timeout': timeout,
            'large_messages': large_messages,
            'tls': tls,
            'unix': unix,
            'wait': wait,
            'lock': lock,
            'no_ctx': no_ctx,
        })
        if system == 'Windows' and unix: # nocov
            raise TypeError('Unix domain sockets cannot be used on Windows')
        if port is None or not isinstance(port, int):
            raise TypeError('IPC port must be provided')
        credentials = f'{normalize_to_str(username, "Username")}:' \
                      f'{normalize_to_str(password, "Password")}'
        object.__setattr__(self, '_lock', lock)
        object.__setattr__(self, 'closed', False)
        object.__setattr__(self,
                           '_handle',
                           _ipc.init_handle(host,
                                            port,
                                            credentials,
                                            unix,
                                            tls,
                                            timeout,
                                            large_messages))
        if licensed:
            object.__setattr__(self, '_finalizer', finalize(self, self._close, self._handle))
        else:
            if self._handle <= 0: # nocov
                raise PyKXException(self._ipc_errors.get(self._handle, 'Unknown IPC error'))
            object.__setattr__(self, '_finalizer', finalize(self, self._close, self._handle))
        if not isinstance(self, SecureQConnection):
            object.__setattr__(self, '_sock', socket.fromfd(self._handle,
                                                            socket.AF_INET,
                                                            socket.SOCK_STREAM))
            self._sock.setblocking(0)
            object.__setattr__(self, '_reader', selectors.DefaultSelector())
            self._reader.register(self._sock, selectors.EVENT_READ, self._recv_socket)
            object.__setattr__(self, '_writer', selectors.DefaultSelector())
            self._writer.register(self._sock, selectors.EVENT_WRITE, self._send_sock)
        object.__setattr__(self, '_timeouts', 0)
        object.__setattr__(self, '_initialized', True)
        super().__init__()
        if no_ctx:
            object.__setattr__(self, '_q_ctx_keys', q._q_ctx_keys)

    def __repr__(self):
        kwargs = get_default_args(type(self))
        # TODO: Once `sync` is completely deprecated out this can be removed.
        if 'sync' in kwargs:
            del kwargs['sync']
        if 'event_loop' in kwargs:
            del kwargs['event_loop']
        for param_name in tuple(kwargs):
            arg = self._connection_info[param_name]
            if arg == kwargs[param_name]: # Remove if equal to default value
                del kwargs[param_name]
            elif param_name == 'password': # Prevent the password from being logged
                kwargs[param_name] = '********'
            else:
                kwargs[param_name] = arg
        if 'host' not in kwargs and self._connection_info['host'] != 'localhost':
            kwargs['host'] = self._connection_info['host']
        if 'port' not in kwargs and self._connection_info['port'] is not None:
            kwargs['port'] = self._connection_info['port']
        return (f'pykx.{"Async" if isinstance(self, AsyncQConnection) else ""}'
                f'QConnection({", ".join(f"{k}={v!r}" for k, v in kwargs.items())})')

    @abstractmethod
    def __call__(self,
                 query: Union[str, bytes, CharVector],
                 *args: Any,
                 wait: Optional[bool] = None,
                 sync: Optional[bool] = None,
    ) -> K:
        pass # nocov

    def _close(self, handle) -> None:
        _ipc._close_handle(handle)

    def _send(self,
              query,
              *params,
              wait: Optional[bool] = None,
    ):
        if self.closed:
            raise RuntimeError("Attempted to use a closed IPC connection")
        start_time = monotonic_ns()
        timeout = self._connection_info['timeout']
        while True:
            if timeout != 0.0 and monotonic_ns() - start_time >= (timeout * 1000000000):
                break
            events = self._writer.select(timeout)
            for key, _mask in events:
                callback = key.data
                return callback(key.fileobj, query, *params, wait=wait)

    def _ipc_query_builder(self, query, *params):
        data = bytes(query, 'utf-8') if isinstance(query, str) else query
        if params:
            data = [data]
            prev_types = [type(data)]
            prev_types.extend([type(x) for x in params])
            data.extend(params)
            data = [K(x) if not isinstance(x, type(None)) else CharVector(x) for x in data]
            for a, b in zip(prev_types, (type(x) for x in data)):
                if not issubclass(a, type(None))\
                   and (issubclass(b, Function) or isinstance(b, Foreign)
                        or (isinstance(b, Composition) and q('{.pykx.isw x}', b))
                   )\
                   and not issubclass(a, Function):
                    raise ValueError('Cannot send Python function over IPC')
        return data

    def _send_sock(self,
                   sock,
                   query,
                   *params,
                   wait: Optional[bool] = None,
    ):
        if len(params) > 8:
            raise TypeError('Too many parameters - q queries cannot have more than 8 parameters')
        query = self._ipc_query_builder(query, *params)
        # The second parameter `1 if wait else 0` sets the value of the second byte of the message
        # to 1 if the message should be sent and a result waited for or a 0 if the message is to be
        # considered async and no result is expected to be returned from the q process.
        # refer to https://code.kx.com/q/kb/serialization/ for more documentation on ipc
        # serialization
        msg_view = _wrappers._to_bytes(3, K(query), 1 if wait else 0)
        msg_len = len(msg_view)
        sent = 0
        while sent < msg_len:
            try:
                sent += sock.send(msg_view[sent:min(msg_len, sent + self._socket_buffer_size)])
            except BlockingIOError: # nocov
                # The only way to get here is if we send too much data to the socket before it can
                # be sent elsewhere, we just need to wait a moment until more data can be sent to
                # the sockets buffer
                pass
            except BaseException:  # nocov
                raise RuntimeError("Failed to send query on IPC socket")
        if isinstance(self, SyncQConnection) or isinstance(self, RawQConnection):
            return
        if wait:
            q_future = QFuture(self, self._connection_info['timeout'])
            self._call_stack.append(q_future)
            return q_future
        else:
            q_future = QFuture(self, self._connection_info['timeout'])
            q_future.set_result(K(None))
            return q_future

    def _recv(self, locked=False):
        timeout = self._connection_info['timeout']
        while self._timeouts > 0:
            events = self._reader.select(timeout)
            for key, _ in events:
                key.data(key.fileobj)
                self._timeouts -= 1
        if isinstance(self, RawQConnection):
            if len(self._send_stack) == len(self._call_stack) and len(self._send_stack) != 0:
                self.poll_send()
        start_time = monotonic_ns()
        with self._lock if self._lock is not None and not locked else nullcontext():
            while True:
                if timeout != 0.0 and monotonic_ns() - start_time >= (timeout * 1000000000):
                    self._timeouts += 1
                    raise QError('Query timed out')
                events = self._reader.select(timeout)
                for key, _ in events:
                    callback = key.data
                    res = callback(key.fileobj)
                    return res

    def _recv_socket(self, sock):
        tot_bytes = 0
        chunks = []
        # message header
        a = sock.recv(8)
        chunks = list(a)
        tot_bytes += 8
        if len(chunks) == 0:
            self.close()
            raise RuntimeError("Attempted to use a closed IPC connection")

        # The last 4 bytes of the header contain the size and the first byte contains information
        # about whether the message is encoded in big-endian or little-endian form
        endianness = chunks[0]
        if endianness == 1: # little-endian
            size = chunks[7]
            for i in range(6, 3, -1):
                size = size << 8
                size += chunks[i]
        else: # nocov
            # big-endian
            size = chunks[4]
            for i in range(5, 8):
                size = size << 8
                size += chunks[i]

        buff = bytearray(size)
        chunks = bytearray(chunks)
        for i in range(8):
            buff[i] = chunks[i]
        view = memoryview(buff)[8:]
        # message body
        while tot_bytes < size:
            try:
                to_read = min(self._socket_buffer_size, size - tot_bytes)
                read = sock.recv_into(view, to_read)
                view = view[read:]
                tot_bytes += read
            except BlockingIOError: # nocov
                # The only way to get here is if we start processing a message before all the data
                # has been received by the socket
                pass
        return self._create_result(buff)

    def _create_error(self, buff):
        try:
            err_msg = [chr(x) for x in buff[9:-1]]
            if len(err_msg) > max_error_length:
                err_msg = err_msg[:max_error_length]
            return QError(''.join(err_msg))
        except BaseException:
            return QError('An unknown exception occured.')

    def _create_result(self, buff):
        if isinstance(self, SyncQConnection) or\
           (isinstance(self, RawQConnection) and len(self._call_stack) == 0):
            # buff[8] contains the responses type and 128 is the type for an error response
            if int(buff[8]) == 128:
                raise self._create_error(buff)
            else:
                return _wrappers.deserialize(memoryview(buff).obj)
        if int(buff[8]) == 128:
            q_future = self._call_stack.pop(0)
            q_future.set_exception(self._create_error(buff))
        else:
            q_future = self._call_stack.pop(0)
            q_future.set_result(_wrappers.deserialize(memoryview(buff).obj))

    def file_execute(
        self,
        file_path: str,
        *,
        return_all: bool = False,
    ):
        """Functionality for the execution of the content of a local file on a remote server

        Parameters:
            file_path: Path to the file which is to be executed on a remote server
            return_all: Return the execution result from all lines within the executed script

        Raises:
            PyKXException: Will raise error associated with failure to execute the code on
                the server associated with the given file.

        Examples:

        Connect to a q process on localhost and execute a file based on relative path.

        ```python
        conn = pykx.QConnection('localhost', 5000)
        conn.file_execute('file.q')
        ```

        Connect to a q process using an asyncronous QConnection at IP address 127.0.0.1,
            on port 5000 and execute a file based on absolute path.

        ```python
        conn = pykx.QConnection('127.0.0.1', 5000, wait=False)
        conn.file_execute('/User/path/to/file.q')
        ```
        """
        with open(pykx_lib_dir/'q.k', 'r') as f:
            lines = f.readlines()
            for line in lines:
                if 'ld:' in line:
                    ld = line[3:]
        with open(file_path) as f:
            lines = f.readlines()
        return self("{[fn;code;file] value (@';last file;enlist[file],/:value[\"k)\",string fn]string code)}",   # noqa : E501
                    ld,
                    lines,
                    bytes(file_path, 'utf-8'),
                    wait=return_all)

    def fileno(self) -> int:
        return self._handle


class SyncQConnection(QConnection):
    def __new__(cls, *args, **kwargs):
        if 'tls' in kwargs.keys() and kwargs['tls']:
            return SecureQConnection(*args, **kwargs)
        return object.__new__(cls)

    def __init__(self,
                 host: Union[str, bytes] = 'localhost',
                 port: int = None,
                 *args,
                 username: Union[str, bytes] = '',
                 password: Union[str, bytes] = '',
                 timeout: float = 0.0,
                 large_messages: bool = True,
                 tls: bool = False,
                 unix: bool = False,
                 sync: Optional[bool] = None,
                 wait: bool = True,
                 lock: Optional[Union[threading_lock, multiprocessing_lock]] = None,
                 no_ctx: bool = False
    ):
        """Interface with a q process using the q IPC protocol.

        Instances of this class represent an open connection to a q process, which can be sent
        messages synchronously or asynchronously by calling it as a function.

        Parameters:
            host: The host name to which a connection is to be established.
            port: The port to which a connection is to be established.
            username: Username for q connection authorization.
            password: Password for q connection authorization.
            timeout: Timeout for blocking socket operations in seconds. If set to `0`, the socket
                will be non-blocking.
            large_messages: Whether support for messages >2GB should be enabled.
            tls: Whether TLS should be used.
            unix: Whether a Unix domain socket should be used instead of TCP. If set to `True`, the
                host parameter is ignored. Does not work on Windows.
            sync: This parameter is deprecated - use `wait` instead.
            wait: Whether the q server should send a response to the query (which this connection
                will wait to receive). Can be overridden on a per-call basis. If `True`, Python will
                wait for the q server to execute the query, and respond with the results. If
                `False`, the q server will respond immediately to every query with generic null
                (`::`), then execute them at some point in the future.
            no_ctx: This parameter determines whether or not the context interface will be disabled.
                disabling the context interface will stop extra q queries being sent but will
                disable the extra features around the context interface.

        Note: The `username` and `password` parameters are not required.
            The `username` and `password` parameters are only required if the q server requires
            authorization. Refer to [ssl documentation](https://code.kx.com/q/kb/ssl/) for more
            information.

        Note: The `timeout` argument may not always be enforced when making succesive querys.
            When making successive queries if one query times out the next query will wait until a
            response has been recieved from the previous query before starting the timer for its own
            timeout. This can be avioded by using a seperate `SyncQConnection` instance for each
            query.

        Note: When querying `KX Insights` the `no_ctx=True` keyword argument must be used.

        Raises:
            PyKXException: Using both tls and unix is not possible with a QConnection.

        Examples:

        Connect to a q process on localhost with a required username and password.

        ```python
        pykx.SyncQConnection('localhost', 5001, 'username', 'password')
        ```

        Connect to a q process at IP address 127.0.0.0, on port 5000 with a timeout of 2 seconds
        and TLS enabled.

        ```python
        pykx.SyncQConnection('127.0.0.1', 5001, timeout=2.0, tls=True)
        ```

        Connect to a q process via a Unix domain socket on port 5001

        ```python
        pykx.SyncQConnection(port=5001, unix=True)
        ```
        """
        # TODO: Once `sync` is completely deprecated out this can be removed.
        if sync is not None:
            warn(self._sync_deprecation_warning, DeprecationWarning)
            wait = sync
        self._init(host,
                   port,
                   *args,
                   username=username,
                   password=password,
                   timeout=timeout,
                   large_messages=large_messages,
                   tls=tls,
                   unix=unix,
                   wait=wait,
                   lock=lock,
                   no_ctx=no_ctx,
        )
        super().__init__()

    def __call__(self,
                 query: Union[str, bytes, CharVector],
                 *args: Any,
                 wait: Optional[bool] = None,
                 sync: Optional[bool] = None,
    ) -> K:
        """Evaluate a query on the connected q process over IPC.

        Parameters:
            query: A q expression to be evaluated.
            *args: Arguments to the q query. Each argument will be converted into a `pykx.K` object.
                Up to 8 arguments can be provided, as that is the maximum supported by q.
            sync: This parameter is deprecated - use `wait` instead.
            wait: Whether the q server should execute the query before responding. If `True`,
                Python will wait for the q server to execute the query, and respond with the
                results. If `False`, the q server will respond immediately to the query with
                generic null (`::`), then execute them at some point in the future. Defaults to
                whatever the `wait` keyword argument was for the `SyncQConnection` instance (i.e.
                this keyword argument overrides the instance-level default).


        Raises:
            RuntimeError: A closed IPC connection was used.
            QError: Query timed out, may be raised if the time taken to make or receive a query goes
                over the timeout limit.
            TypeError: Too many arguments were provided - q queries cannot have more than 8
                parameters.
            ValueError: Attempted to send a Python function over IPC.

        Examples:

        ```python
        q = pykx.SyncQConnection(host='localhost', port=5002)
        ```

        Call an anonymous function with 2 parameters

        ```python
        q('{y+til x}', 10, 5)
        ```

        Execute a q query with no parameters

        ```python
        q('til 10')
        ```

        Call an anonymous function with 3 parameters and don't wait for a response

        ```python
        q('{x set y+til z}', 'async_query', 10, 5, wait=False)
        ```

        Call an anonymous function with 3 parameters and don't wait for a response by default

        ```python
        q = pykx.SyncQConnection(host='localhost', port=5002, wait=False)
        # Because `wait=False`, all calls on this q instance are not responded to by default:
        q('{x set y+til z}', 'async_query', 10, 5)
        # But we can issue calls and wait for results by overriding the `wait` option on a per-call
        # basis:
        q('{x set y+til z}', 'async_query', 10, 5, wait=True)
        ```
        """
        # TODO: Once `sync` is completely deprecated out this can be removed.
        if sync is not None:
            warn(self._sync_deprecation_warning, DeprecationWarning)
            wait = sync
        if wait is None:
            wait = self._connection_info['wait']
        with self._lock if self._lock is not None else nullcontext():
            return self._call(query, *args, wait=wait)

    def _call(self,
              query: Union[str, bytes],
              *args: Any,
              wait: Optional[bool] = None,
    ) -> K:
        self._send(query, *args, wait=wait)
        if not wait:
            return K(None)
        return self._recv(locked=True)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self) -> None:
        """Close the connection.

        Examples:

        Open and subsequently close a connection to a q process on localhost:

        ```python
        q = pykx.SyncQConnection('localhost', 5001)
        q.close()
        ```

        Using this class with a with-statement should be preferred:

        ```python
        with pykx.SyncQConnection('localhost', 5001) as q:
            # do stuff with q
            pass
        # q is closed automatically
        ```
        """
        if not self.closed:
            object.__setattr__(self, 'closed', True)
            self._reader.unregister(self._sock)
            self._writer.unregister(self._sock)
            self._sock.close()
            self._finalizer()

    def fileno(self) -> int:
        """The file descriptor or handle of the connection."""
        return super().fileno()


class AsyncQConnection(QConnection):
    def __init__(self,
                 host: Union[str, bytes] = 'localhost',
                 port: int = None,
                 *args,
                 username: Union[str, bytes] = '',
                 password: Union[str, bytes] = '',
                 timeout: float = 0.0,
                 large_messages: bool = True,
                 tls: bool = False,
                 unix: bool = False,
                 wait: bool = True,
                 lock: Optional[Union[threading_lock, multiprocessing_lock]] = None,
                 event_loop: Optional[asyncio.AbstractEventLoop] = None,
                 no_ctx: bool = False
    ):
        """Interface with a q process using the q IPC protocol.

        Instances of this class represent an open connection to a q process, which can be sent
        messages asynchronously by calling it as a function.

        Parameters:
            host: The host name to which a connection is to be established.
            port: The port to which a connection is to be established.
            username: Username for q connection authorization.
            password: Password for q connection authorization.
            timeout: Timeout for blocking socket operations in seconds. If set to `0`, the socket
                will be non-blocking.
            large_messages: Whether support for messages >2GB should be enabled.
            tls: Whether TLS should be used.
            unix: Whether a Unix domain socket should be used instead of TCP. If set to `True`, the
                host parameter is ignored. Does not work on Windows.
            wait: Whether the q server should send a response to the query (which this connection
                will wait to receive). Can be overridden on a per-call basis. If `True`, Python will
                wait for the q server to execute the query, and respond with the results. If
                `False`, the q server will respond immediately to every query with generic null
                (`::`), then execute them at some point in the future.
            event_loop: If running an event loop that supports the `create_task()` method then
                you can provide the event loop here and the returned future object will be an
                instance of the loops future type. This will allow the current event loop to manage
                awaiting `QFuture` objects as well as any other async tasks that may be running.
            no_ctx: This parameter determines whether or not the context interface will be disabled.
                disabling the context interface will stop extra q queries being sent but will
                disable the extra features around the context interface.

        Note: The `username` and `password` parameters are not required.
            The `username` and `password` parameters are only required if the q server requires
            authorization. Refer to [ssl documentation](https://code.kx.com/q/kb/ssl/) for more
            information.

        Note: The `timeout` argument may not always be enforced when making succesive querys.
            When making successive queries if one query times out the next query will wait until a
            response has been recieved from the previous query before starting the timer for its own
            timeout. This can be avioded by using a seperate `QConnection` instance for each query.

        Note: When querying `KX Insights` the `no_ctx=True` keyword argument must be used.

        Raises:
            PyKXException: Using both tls and unix is not possible with a QConnection.

        Examples:

        Connect to a q process on localhost with a required username and password.

        ```python
        await pykx.AsyncQConnection('localhost', 5001, 'username', 'password')
        ```

        Connect to a q process at IP address 127.0.0.0, on port 5000 with a timeout of 2 seconds
        and TLS enabled.

        ```python
        await pykx.AsyncQConnection('127.0.0.1', 5001, timeout=2.0, tls=True)
        ```

        Connect to a q process via a Unix domain socket on port 5001

        ```python
        await pykx.AsyncQConnection(port=5001, unix=True)
        ```
        """
        # TODO: Remove this once TLS support is fixed
        if tls:
            raise PyKXException('TLS is currently only supported for SyncQConnections')
        object.__setattr__(self, '_stored_args', {
            'host': host,
            'port': port,
            'args': args,
            'username': username,
            'password': password,
            'timeout': timeout,
            'large_messages': large_messages,
            'tls': tls,
            'unix': unix,
            'wait': wait,
            'lock': lock,
            'loop': event_loop,
            'no_ctx': no_ctx,
        })
        object.__setattr__(self, '_initialized', False)

    async def _async_init(self,
                          host: Union[str, bytes] = 'localhost',
                          port: int = None,
                          *args,
                          username: Union[str, bytes] = '',
                          password: Union[str, bytes] = '',
                          timeout: float = 0.0,
                          large_messages: bool = True,
                          tls: bool = False,
                          unix: bool = False,
                          wait: bool = True,
                          lock: Optional[Union[threading_lock, multiprocessing_lock]] = None,
                          event_loop: Optional[asyncio.AbstractEventLoop] = None,
                          no_ctx: bool = False
    ):
        object.__setattr__(self, '_call_stack', [])
        self._init(host,
                   port,
                   *args,
                   username=username,
                   password=password,
                   timeout=timeout,
                   large_messages=large_messages,
                   tls=tls,
                   unix=unix,
                   wait=wait,
                   lock=lock,
                   no_ctx=no_ctx
        )
        object.__setattr__(self, '_loop', event_loop)
        con_info = object.__getattribute__(self, '_connection_info')
        con_info['event_loop'] = None
        object.__setattr__(self, '_connection_info', con_info)
        super().__init__()

    async def _initobj(self): # nocov
        """Crutch used for `__await__` after spawning."""
        if not self._initialized:
            await self._async_init(self._stored_args['host'],
                                   self._stored_args['port'],
                                   *self._stored_args['args'],
                                   username=self._stored_args['username'],
                                   password=self._stored_args['password'],
                                   timeout=self._stored_args['timeout'],
                                   large_messages=self._stored_args['large_messages'],
                                   tls=self._stored_args['tls'],
                                   unix=self._stored_args['unix'],
                                   wait=self._stored_args['wait'],
                                   lock=self._stored_args['lock'],
                                   event_loop=self._stored_args['loop'],
                                   no_ctx=self._stored_args['no_ctx'])
        return self

    def __await__(self):
        return self._initobj().__await__()

    def __call__(self,
                 query: Union[str, bytes, CharVector],
                 *args: Any,
                 wait: bool = True,
                 reuse: bool = True,
    ) -> QFuture:
        """Evaluate a query on the connected q process over IPC.

        Parameters:
            query: A q expression to be evaluated.
            *args: Arguments to the q query. Each argument will be converted into a `pykx.K` object.
                Up to 8 arguments can be provided, as that is the maximum supported by q.
            wait: Whether the q server should execute the query before responding. If `True`,
                Python will wait for the q server to execute the query, and respond with the
                results. If `False`, the q server will respond immediately to the query with
                generic null (`::`), then execute them at some point in the future. Defaults to
                whatever the `wait` keyword argument was for the `ASyncQConnection` instance (i.e.
                this keyword argument overrides the instance-level default).
            reuse: Whether the AsyncQConnection instance should be reused for subsequent queries,
                if using q queries that respond in a deferred/asynchronous manner this should be set
                to `False` so the query can be made in a dedicated `AsyncQConnection` instance.

        Returns:
            A QFuture object that can be awaited on to get the result of the query.

        Raises:
            RuntimeError: A closed IPC connection was used.
            QError: Query timed out, may be raised if the time taken to make or receive a query goes
                over the timeout limit.
            TypeError: Too many arguments were provided - q queries cannot have more than 8
                parameters.
            ValueError: Attempted to send a Python function over IPC.

        Examples:

        ```python
        q = await pykx.AsyncQConnection(host='localhost', port=5002)
        ```

        Call an anonymous function with 2 parameters

        ```python
        await q('{y+til x}', 10, 5)
        ```

        Execute a q query with no parameters

        ```python
        await q('til 10')
        ```

        Call an anonymous function with 3 parameters and don't wait for a response

        ```python
        await q('{x set y+til z}', 'async_query', 10, 5, wait=False)
        ```

        Call an anonymous function with 3 parameters and don't wait for a response by default

        ```python
        q = await pykx.AsyncQConnection(host='localhost', port=5002, wait=False)
        # Because `wait=False`, all calls on this q instance are not responded to by default:
        await q('{x set y+til z}', 'async_query', 10, 5)
        # But we can issue calls and wait for results by overriding the `wait` option on a per-call
        # basis:
        await q('{x set y+til z}', 'async_query', 10, 5, wait=True)
        ```
        """
        if not reuse:
            conn = _DeferredQConnection(self._stored_args['host'],
                                        self._stored_args['port'],
                                        *self._stored_args['args'],
                                        username=self._stored_args['username'],
                                        password=self._stored_args['password'],
                                        timeout=self._stored_args['timeout'],
                                        large_messages=self._stored_args['large_messages'],
                                        tls=self._stored_args['tls'],
                                        unix=self._stored_args['unix'],
                                        wait=self._stored_args['wait'],
                                        no_ctx=self._stored_args['no_ctx'])
            q_future = conn(query, *args, wait=wait)
            q_future.add_done_callback(lambda x: conn.close())
            if self._loop is None:
                return q_future
            return self._loop.create_task(q_future.__async_await__())
        else:
            if not self._initialized:
                raise UninitializedConnection()
            with self._lock if self._lock is not None else nullcontext():
                q_future = self._send(query, *args, wait=wait)
                if self._loop is None:
                    return q_future
                return self._loop.create_task(q_future.__async_await__())

    def _call(self,
              query: Union[str, bytes],
              *args: Any,
              wait: Optional[bool] = None,
    ):
        with self._lock if self._lock is not None else nullcontext():
            return self._send(query, *args, wait=wait)._await()

    async def __aenter__(self):
        return await self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def close(self) -> None:
        """Close the connection.

        Examples:

        Open and subsequently close a connection to a q process on localhost:

        ```python
        q = await pykx.AsyncQConnection('localhost', 5001)
        await q.close()
        ```

        Using this class with a with-statement should be preferred:

        ```python
        async with pykx.AsyncQConnection('localhost', 5001) as q:
            # do stuff with q
            pass
        # q is closed automatically
        ```
        """
        if not self._initialized:
            raise UninitializedConnection()
        if not self.closed:
            object.__setattr__(self, 'closed', True)
            while self._call_stack != []:
                events = self._reader.select()
                for key, _mask in events:
                    callback = key.data
                    callback(key.fileobj)
            self._reader.unregister(self._sock)
            self._writer.unregister(self._sock)
            self._sock.close()
            self._finalizer()

    def fileno(self) -> int:
        """The file descriptor or handle of the connection."""
        if not self._initialized:
            raise UninitializedConnection()
        return self._handle


class _DeferredQConnection(QConnection):
    def __init__(self,
                 host: Union[str, bytes] = 'localhost',
                 port: int = None,
                 *args,
                 username: Union[str, bytes] = '',
                 password: Union[str, bytes] = '',
                 timeout: float = 0.0,
                 large_messages: bool = True,
                 tls: bool = False,
                 unix: bool = False,
                 wait: bool = True,
                 no_ctx: bool = False
    ):
        object.__setattr__(self, '_call_stack', [])
        self._init(host,
                   port,
                   *args,
                   username=username,
                   password=password,
                   timeout=timeout,
                   large_messages=large_messages,
                   tls=tls,
                   unix=unix,
                   wait=wait,
                   no_ctx=no_ctx,
        )
        super().__init__()

    def __call__(self,
                 query: Union[str, bytes, CharVector],
                 *args: Any,
                 wait: Optional[bool] = None,
    ) -> K:
        return self._send(query, *args, wait=wait)

    def _call(self,
              query: Union[str, bytes],
              *args: Any,
              wait: Optional[bool] = None,
    ):
        return self._send(query, *args, wait=wait)._await()

    def close(self) -> None:
        if not self.closed: # nocov
            object.__setattr__(self, 'closed', True)
            while self._call_stack != []:
                events = self._reader.select()
                for key, _mask in events:
                    callback = key.data
                    callback(key.fileobj)
            self._reader.unregister(self._sock)
            self._writer.unregister(self._sock)
            self._sock.close()
            self._finalizer()


class RawQConnection(QConnection):
    def __init__(self,
                 host: Union[str, bytes] = 'localhost',
                 port: int = None,
                 *args,
                 username: Union[str, bytes] = '',
                 password: Union[str, bytes] = '',
                 timeout: float = 0.0,
                 large_messages: bool = True,
                 tls: bool = False,
                 unix: bool = False,
                 wait: bool = True,
                 event_loop: Optional[asyncio.AbstractEventLoop] = None,
                 no_ctx: bool = False,
    ):
        """Interface with a q process using the q IPC protocol.

        Instances of this class represent an open connection to a q process, which can be sent
        messages asynchronously by calling it as a function, the send and receive selector queues
        can also, be polled directly using this class.

        Parameters:
            host: The host name to which a connection is to be established.
            port: The port to which a connection is to be established.
            username: Username for q connection authorization.
            password: Password for q connection authorization.
            timeout: Timeout for blocking socket operations in seconds. If set to `0`, the socket
                will be non-blocking.
            large_messages: Whether support for messages >2GB should be enabled.
            tls: Whether TLS should be used.
            unix: Whether a Unix domain socket should be used instead of TCP. If set to `True`, the
                host parameter is ignored. Does not work on Windows.
            wait: Whether the q server should send a response to the query (which this connection
                will wait to receive). Can be overridden on a per-call basis. If `True`, Python will
                wait for the q server to execute the query, and respond with the results. If
                `False`, the q server will respond immediately to every query with generic null
                (`::`), then execute them at some point in the future.
            event_loop: If running an event loop that supports the `create_task()` method then
                you can provide the event loop here and the returned future object will be an
                instance of the loops future type. This will allow the current event loop to manage
                awaiting `QFuture` objects as well as any other async tasks that may be running.
            no_ctx: This parameter determines whether or not the context interface will be disabled.
                disabling the context interface will stop extra q queries being sent but will
                disable the extra features around the context interface.

        Note: The `username` and `password` parameters are not required.
            The `username` and `password` parameters are only required if the q server requires
            authorization. Refer to [ssl documentation](https://code.kx.com/q/kb/ssl/) for more
            information.

        Note: The `timeout` argument may not always be enforced when making successive queries.
            When making successive queries if one query times out the next query will wait until a
            response has been recieved from the previous query before starting the timer for its own
            timeout. This can be avoided by using a separate `QConnection` instance for each query.

        Note: When querying `KX Insights` the `no_ctx=True` keyword argument must be used.

        Raises:
            PyKXException: Using both tls and unix is not possible with a QConnection.

        Examples:

        Connect to a q process on localhost with a required username and password.

        ```python
        await pykx.RawQConnection('localhost', 5001, 'username', 'password')
        ```

        Connect to a q process at IP address 127.0.0.0, on port 5000 with a timeout of 2 seconds
        and TLS enabled.

        ```python
        await pykx.RawQConnection('127.0.0.1', 5001, timeout=2.0, tls=True)
        ```

        Connect to a q process via a Unix domain socket on port 5001

        ```python
        await pykx.RawQConnection(port=5001, unix=True)
        ```
        """
        # TODO: Remove this once TLS support is fixed
        if tls:
            raise PyKXException('TLS is currently only supported for SyncQConnections')
        object.__setattr__(self, '_stored_args', {
            'host': host,
            'port': port,
            'args': args,
            'username': username,
            'password': password,
            'timeout': timeout,
            'large_messages': large_messages,
            'tls': tls,
            'unix': unix,
            'wait': wait,
            'loop': event_loop,
            'no_ctx': no_ctx,
        })
        object.__setattr__(self, '_initialized', False)

    async def _async_init(self,
                          host: Union[str, bytes] = 'localhost',
                          port: int = None,
                          *args,
                          username: Union[str, bytes] = '',
                          password: Union[str, bytes] = '',
                          timeout: float = 0.0,
                          large_messages: bool = True,
                          tls: bool = False,
                          unix: bool = False,
                          wait: bool = True,
                          event_loop: Optional[asyncio.AbstractEventLoop] = None,
                          no_ctx: bool = False
    ):
        object.__setattr__(self, '_call_stack', [])
        object.__setattr__(self, '_send_stack', [])
        self._init(host,
                   port,
                   *args,
                   username=username,
                   password=password,
                   timeout=timeout,
                   large_messages=large_messages,
                   tls=tls,
                   unix=unix,
                   wait=wait,
                   no_ctx=no_ctx
        )
        object.__setattr__(self, '_loop', event_loop)
        con_info = object.__getattribute__(self, '_connection_info')
        con_info['event_loop'] = None
        object.__setattr__(self, '_connection_info', con_info)
        super().__init__()

    async def _initobj(self): # nocov
        """Crutch used for `__await__` after spawning."""
        if not self._initialized:
            await self._async_init(self._stored_args['host'],
                                   self._stored_args['port'],
                                   *self._stored_args['args'],
                                   username=self._stored_args['username'],
                                   password=self._stored_args['password'],
                                   timeout=self._stored_args['timeout'],
                                   large_messages=self._stored_args['large_messages'],
                                   tls=self._stored_args['tls'],
                                   unix=self._stored_args['unix'],
                                   wait=self._stored_args['wait'],
                                   event_loop=self._stored_args['loop'],
                                   no_ctx=self._stored_args['no_ctx'])
        return self

    def __await__(self):
        return self._initobj().__await__()

    def __call__(self,
                 query: Union[str, bytes, CharVector],
                 *args: Any,
                 wait: bool = True,
    ) -> QFuture:
        """Evaluate a query on the connected q process over IPC.

        Parameters:
            query: A q expression to be evaluated.
            *args: Arguments to the q query. Each argument will be converted into a `pykx.K` object.
                Up to 8 arguments can be provided, as that is the maximum supported by q.
            wait: Whether the q server should execute the query before responding. If `True`,
                Python will wait for the q server to execute the query, and respond with the
                results. If `False`, the q server will respond immediately to the query with
                generic null (`::`), then execute them at some point in the future. Defaults to
                whatever the `wait` keyword argument was for the `ASyncQConnection` instance (i.e.
                this keyword argument overrides the instance-level default).
            reuse: Whether the AsyncQConnection instance should be reused for subsequent queries,
                if using q queries that respond in a deferred/asynchronous manner this should be set
                to `False` so the query can be made in a dedicated `AsyncQConnection` instance.

        Returns:
            A QFuture object that can be awaited on to get the result of the query.

        Raises:
            RuntimeError: A closed IPC connection was used.
            QError: Query timed out, may be raised if the time taken to make or receive a query goes
                over the timeout limit.
            TypeError: Too many arguments were provided - q queries cannot have more than 8
                parameters.
            ValueError: Attempted to send a Python function over IPC.

        Note: Queries are not sent until a response has been awaited or the send queue is polled.

        Note: When querying `KX Insights` the `no_ctx=True` keyword argument must be used.

        Examples:

        ```python
        q = await pykx.RawQConnection(host='localhost', port=5002)
        ```

        Call an anonymous function with 2 parameters

        ```python
        await q('{y+til x}', 10, 5)
        ```

        Execute a q query with no parameters

        ```python
        await q('til 10')
        ```

        Call an anonymous function with 3 parameters and don't wait for a response

        ```python
        await q('{x set y+til z}', 'async_query', 10, 5, wait=False)
        ```

        Call an anonymous function with 3 parameters and don't wait for a response by default

        ```python
        q = await pykx.RawQConnection(host='localhost', port=5002, wait=False)
        # Because `wait=False`, all calls on this q instance are not responded to by default:
        await q('{x set y+til z}', 'async_query', 10, 5)
        # But we can issue calls and wait for results by overriding the `wait` option on a per-call
        # basis:
        await q('{x set y+til z}', 'async_query', 10, 5, wait=True)
        ```
        """
        if not self._initialized:
            raise UninitializedConnection()
        res = QFuture(self, self._connection_info['timeout'])
        self._send_stack.append({'query': query, 'args': args, 'wait': wait})
        self._call_stack.append(res)
        return res

    def _call(self,
              query: Union[str, bytes],
              *args: Any,
              wait: Optional[bool] = None,
    ):
        conn = _DeferredQConnection(self._stored_args['host'],
                                    self._stored_args['port'],
                                    *self._stored_args['args'],
                                    username=self._stored_args['username'],
                                    password=self._stored_args['password'],
                                    timeout=self._stored_args['timeout'],
                                    large_messages=self._stored_args['large_messages'],
                                    tls=self._stored_args['tls'],
                                    unix=self._stored_args['unix'],
                                    wait=self._stored_args['wait'],
                                    no_ctx=self._stored_args['no_ctx'])
        q_future = conn(query, *args, wait=wait)
        q_future.add_done_callback(lambda x: conn.close())
        return q_future._await()

    def poll_send(self, amount: int = 1):
        """Send queued queries to the process connected to over IPC.

        Parameters:
            amount: The number of send requests to handle, defaults to one, if 0 is used then all
                currently waiting queries will be sent.

        Raises:
            QError: Query timed out, may be raised if the time taken to make or receive a query goes
                over the timeout limit.

        Examples:

        ```python
        q = await pykx.RawQConnection(host='localhost', port=5002)
        ```

        Send a single queued message.

        ```python
        q_fut = q('til 10') # not sent yet
        q.poll_send() # 1 message is sent
        ```

        Send two queued messages.

        ```python
        q_fut = q('til 10') # not sent yet
        q_fut2 = q('til 10') # not sent yet
        q.poll_send(2) # 2 messages are sent
        ```

        Send all queued messages.

        ```python
        q_fut = q('til 10') # not sent yet
        q_fut2 = q('til 10') # not sent yet
        q.poll_send(0) # 2 messages are sent
        ```
        """
        count = amount
        if count == 0:
            count = len(self._send_stack)
        while count > 0:
            if not self._initialized:
                raise UninitializedConnection()
            if len(self._send_stack) == 0:
                return
            to_send = self._send_stack.pop(0)
            self._send(to_send['query'], *to_send['args'], wait=to_send['wait'])
            count -= 1

    def poll_recv(self, amount: int = 1):
        """Recieve queries from the process connected to over IPC.

        Parameters:
            amount: The number of receive requests to handle, defaults to one, if 0 is used then
                all currently waiting responses will be received.

        Raises:
            QError: Query timed out, may be raised if the time taken to make or receive a query goes
                over the timeout limit.

        Examples:

        ```python
        q = await pykx.RawQConnection(host='localhost', port=5002)
        ```

        Receive a single queued message.

        ```python
        q_fut = q('til 10') # not sent yet
        q.poll_send() # message is sent
        q.poll_recv() # message response is received
        ```

        Receive two queued messages.

        ```python
        q_fut = q('til 10') # not sent yet
        q_fut2 = q('til 10') # not sent yet
        q.poll_send(2) # messages are sent
        q.poll_recv(2) # message responses are received
        ```

        Receive all queued messages.

        ```python
        q_fut = q('til 10') # not sent yet
        q_fut2 = q('til 10') # not sent yet
        q.poll_send(0) # all messages are sent
        q.poll_recv(0) # all message responses are received
        ```
        """
        last = None
        count = amount
        if count == 0:
            count = len(self._call_stack) if len(self._call_stack) > 0 else 1
        while count >= 0:
            timeout = self._connection_info['timeout']
            start_time = monotonic_ns()
            with self._lock if self._lock is not None else nullcontext():
                if timeout != 0.0 and monotonic_ns() - start_time >= (timeout * 1000000000):
                    self._timeouts += 1
                    raise QError('Query timed out')
                events = self._reader.select(timeout)
                if len(events) != 0:
                    for key, _ in events:
                        callback = key.data
                        res = callback(key.fileobj)
                        if count == 1:
                            return res
                        count -= 1
                        last = res
                else:
                    if count == 1:
                        return last
                    count -= 1

    async def __aenter__(self):
        return await self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def close(self) -> None:
        """Close the connection.

        Examples:

        Open and subsequently close a connection to a q process on localhost:

        ```python
        q = await pykx.RawQConnection('localhost', 5001)
        await q.close()
        ```

        Using this class with a with-statement should be preferred:

        ```python
        async with pykx.RawQConnection('localhost', 5001) as q:
            # do stuff with q
            pass
        # q is closed automatically
        ```
        """
        if not self._initialized:
            raise UninitializedConnection()
        if not self.closed:
            object.__setattr__(self, 'closed', True)
            while self._call_stack != []:
                events = self._reader.select()
                for key, _mask in events:
                    callback = key.data
                    callback(key.fileobj)
            self._reader.unregister(self._sock)
            self._writer.unregister(self._sock)
            self._sock.close()
            self._finalizer()


class SecureQConnection(QConnection):
    def __init__(self,
                 host: Union[str, bytes] = 'localhost',
                 port: int = None,
                 *args,
                 username: Union[str, bytes] = '',
                 password: Union[str, bytes] = '',
                 timeout: float = 0.0,
                 large_messages: bool = True,
                 tls: bool = False,
                 unix: bool = False,
                 sync: Optional[bool] = None,
                 wait: bool = True,
                 lock: Optional[Union[threading_lock, multiprocessing_lock]] = None,
                 no_ctx: bool = False
    ):
        """Interface with a q process using the q IPC protocol.

        Instances of this class represent an open connection to a q process, which can be sent
        messages synchronously or asynchronously by calling it as a function. This class is
        automatically created when using TLS to encrypt your queries.

        Parameters:
            host: The host name to which a connection is to be established.
            port: The port to which a connection is to be established.
            username: Username for q connection authorization.
            password: Password for q connection authorization.
            timeout: Timeout for blocking socket operations in seconds. If set to `0`, the socket
                will be non-blocking.
            large_messages: Whether support for messages >2GB should be enabled.
            tls: Whether TLS should be used.
            unix: Whether a Unix domain socket should be used instead of TCP. If set to `True`, the
                host parameter is ignored. Does not work on Windows.
            sync: This parameter is deprecated - use `wait` instead.
            wait: Whether the q server should send a response to the query (which this connection
                will wait to receive). Can be overridden on a per-call basis. If `True`, Python will
                wait for the q server to execute the query, and respond with the results. If
                `False`, the q server will respond immediately to every query with generic null
                (`::`), then execute them at some point in the future.
            no_ctx: This parameter determines whether or not the context interface will be disabled.
                disabling the context interface will stop extra q queries being sent but will
                disable the extra features around the context interface.

        Note: The `username` and `password` parameters are not required.
            The `username` and `password` parameters are only required if the q server requires
            authorization. Refer to [ssl documentation](https://code.kx.com/q/kb/ssl/) for more
            information.

        Note: The `timeout` argument may not always be enforced when making succesive querys.
            When making successive queries if one query times out the next query will wait until a
            response has been recieved from the previous query before starting the timer for its own
            timeout. This can be avioded by using a seperate `SecureQConnection` instance for each
            query.

        Note: When querying `KX Insights` the `no_ctx=True` keyword argument must be used.

        Raises:
            PyKXException: Using both tls and unix is not possible with a QConnection.

        Examples:

        Connect to a q process at IP address 127.0.0.0, on port 5000 with a timeout of 2 seconds
        and TLS enabled.

        ```python
        pykx.SecureQConnection('127.0.0.1', 5001, timeout=2.0, tls=True)
        ```
        """
        # TODO: Once `sync` is completely deprecated out this can be removed.
        if sync is not None:
            warn(self._sync_deprecation_warning, DeprecationWarning)
            wait = sync
        self._init(host,
                   port,
                   *args,
                   username=username,
                   password=password,
                   timeout=timeout,
                   large_messages=large_messages,
                   tls=tls,
                   unix=unix,
                   wait=wait,
                   lock=lock,
                   no_ctx=no_ctx,
        )
        super().__init__()

    @staticmethod
    def _licensed_call(handle: int, query: bytes, parameters: List, wait: bool) -> K:
        ret = q(f'{{{handle} x}}', [query, *parameters] if parameters else query)
        if not wait:
            q(f'{handle}[]')
        return ret

    # TODO: can we switch over to exclusively using this approach instead of `_licensed_call`?
    # It would involve making `cls._lib` be either libq or libe depending on if we're licensed.
    @classmethod
    def _unlicensed_call(cls, handle: int, query: bytes, parameters: List, wait: bool) -> K:
        return _ipc._unlicensed_call(handle, query, parameters, wait)

    def __call__(self,
                 query: Union[str, bytes, CharVector],
                 *args: Any,
                 wait: Optional[bool] = None,
                 sync: Optional[bool] = None,
    ) -> K:
        """Evaluate a query on the connected q process over IPC.

        Parameters:
            query: A q expression to be evaluated.
            *args: Arguments to the q query. Each argument will be converted into a `pykx.K` object.
                Up to 8 arguments can be provided, as that is the maximum supported by q.
            sync: This parameter is deprecated - use `wait` instead.
            wait: Whether the q server should execute the query before responding. If `True`,
                Python will wait for the q server to execute the query, and respond with the
                results. If `False`, the q server will respond immediately to the query with
                generic null (`::`), then execute them at some point in the future. Defaults to
                whatever the `wait` keyword argument was for the `SecureQConnection` instance (i.e.
                this keyword argument overrides the instance-level default).


        Raises:
            RuntimeError: A closed IPC connection was used.
            QError: Query timed out, may be raised if the time taken to make or receive a query goes
                over the timeout limit.
            TypeError: Too many arguments were provided - q queries cannot have more than 8
                parameters.
            ValueError: Attempted to send a Python function over IPC.

        Examples:

        ```python
        q = pykx.SecureQConnection(host='localhost', port=5002, tls=True)
        ```

        Call an anonymous function with 2 parameters

        ```python
        q('{y+til x}', 10, 5)
        ```

        Execute a q query with no parameters

        ```python
        q('til 10')
        ```

        Call an anonymous function with 3 parameters and don't wait for a response

        ```python
        q('{x set y+til z}', 'async_query', 10, 5, wait=False)
        ```

        Call an anonymous function with 3 parameters and don't wait for a response by default

        ```python
        q = pykx.SecureQConnection(host='localhost', port=5002, wait=False, tls=True)
        # Because `wait=False`, all calls on this q instance are not responded to by default:
        q('{x set y+til z}', 'async_query', 10, 5)
        # But we can issue calls and wait for results by overriding the `wait` option on a per-call
        # basis:
        q('{x set y+til z}', 'async_query', 10, 5, wait=True)
        ```
        """
        # TODO: Once `sync` is completely deprecated out this can be removed.
        if sync is not None:
            warn(self._sync_deprecation_warning, DeprecationWarning)
            wait = sync
        return self._call(query, *args, wait=wait)

    def _call(self,
              query: Union[str, bytes],
              *args: Any,
              wait: Optional[bool] = None,
    ) -> K:
        if wait is None:
            wait = self._connection_info['wait']
        if self.closed:
            raise RuntimeError('Attempted to use a closed IPC connection')
        if len(args) > 8:
            raise TypeError('Too many parameters - q queries cannot have more than 8 parameters')
        prev_types = [type(x) for x in args]
        handle = self._handle if wait else -self._handle
        args = [K(x) for x in args]
        for a, b in zip(prev_types, (type(x) for x in args)):
            if issubclass(b, Function) and not issubclass(a, Function):
                raise ValueError('Cannot send Python function over IPC')
        handler = self._licensed_call if licensed else self._unlicensed_call
        with self._lock if self._lock is not None else nullcontext():
            return handler(handle, normalize_to_bytes(query, 'Query'), args, wait)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self) -> None:
        """Close the connection.

        Examples:

        Open and subsequently close a connection to a q process on localhost:

        ```python
        q = pykx.SecureQConnection('localhost', 5001, tls=True)
        q.close()
        ```

        Using this class with a with-statement should be preferred:

        ```python
        with pykx.SecureQConnection('localhost', 5001, tls=True) as q:
            # do stuff with q
            pass
        # q is closed automatically
        ```
        """
        if not self.closed:
            object.__setattr__(self, 'closed', True)
            self._finalizer()

    def fileno(self) -> int:
        """The file descriptor or handle of the connection."""
        return super().fileno()
